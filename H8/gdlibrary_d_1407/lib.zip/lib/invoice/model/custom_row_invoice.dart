class CustomRow {
  final String itemName;
  final String itemPrice;
  final String amount;
  final String subTotalProduct;

  CustomRow(this.itemName, this.itemPrice, this.amount, this.subTotalProduct);
}

class Product {
  final String name;
  final double price;
  final double ppnInPercent = 11;
  int amount = 0;

  Product(this.name, this.price);
}
